                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1761794
Drag Knife - Cuchilla de corte para CNC (papel, vinilo, etc.) by onasiis is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

Hi, I have created this tool based on my previous aluminium version, because some users asked me for this printable version.
I have performed some modifications on the aluminium version to get a good and hard printable version.

You can find more information about the aluminium version here:
http://cnccontrol.byethost13.com/smf/index.php?topic=977.0

If you want to see the tool working:
https://www.youtube.com/watch?v=uiobecsMp78

You have to add 6mm stem to be able hold the tool in the cnc's spindle. As you can see in the pictures, you can use a vise to do this task.
The ball bearing used are the 608ZZ model.


# Print Settings

Printer: Sunhokey Prusa I3
Rafts: No
Supports: Yes
Resolution: 0.4mm
Infill: 100%